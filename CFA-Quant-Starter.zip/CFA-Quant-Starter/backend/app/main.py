from fastapi import FastAPI

app = FastAPI(title="CFA Quant", version="0.1.0")

@app.get("/")
def root():
    return {"project":"CFA Quant","version":"0.1.0"}

@app.get("/health")
def health():
    return {"status":"ok"}
