# CFA Quant

Primeira versão do projeto.

## Executar

```bash
docker compose up --build
```
